<?php
return array (
		'title' => '详情v-2',
		'author' => 'jacy',
		'desc' => ''
);					