<?php
return array (
		'title' => '图文列表V-1',
		'author' => 'jacy',
		'desc' => ''
);					