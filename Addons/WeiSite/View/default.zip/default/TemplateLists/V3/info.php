<?php
return array (
		'title' => '图文列表V-3(大图)',
		'author' => 'jacy',
		'desc' => ''
);					