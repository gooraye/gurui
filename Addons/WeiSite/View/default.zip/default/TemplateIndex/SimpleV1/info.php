<?php
return array (
		'title' => '简约V-1',
		'author' => 'jacy',
		'desc' => 'banner尺寸大小 640X300'
);					